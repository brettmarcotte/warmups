package com.company;

public class Main {

    public static void main(String[] args) {
	// warmup 1
        public static int findPerimeter(int length, int width) {
            return 2*(length + width);
        }
    // warmup2
        public static boolean divisible(int num) {
            return (num % 100 == 0);
        }
    // warmup3
        public static int countWords(String s) {
            String[] split = s.split(" ");
            return split.length;
        }
    // warmup 4
        public static boolean checkEnding(String str1, String str2) {
            if(str1.endsWith(str2)) {
                return true;
            } else {
                return false;
            }
        }
    // warmup5
        public static String isEvenOrOdd(int num) {
            if(num % 2 == 0) {
                return "even";
            } else {
                return "odd";
            }
        }
        // warmup 6
        public static int getCount(String str) {
            int vowelsCount = 0;
            String vowels = new String("aeiou");
            for(int i = 0; i < vowels.length(); i++){
                for(int j = 0; j < str.length(); j++){
                    if(vowels.charAt(i)==str.charAt(j)){
                        vowelsCount += 1;

                    }
                }
            }
            return vowelsCount;
        }
        //warmup 7
        public static boolean existsHigher(int[] arr, int n) {
            int count = 0;
            for(int i=0; i<arr.length; i++){
                if(arr[i] >= n){
                    count++;
                }
            }
            return count >= 1;
        }
        //warmup 8
        public static int calculator(int num1, char operator, int num2) {

            switch(operator)
            {
                case '+':
                    return num1 + num2;
                case '-':
                    return num1 - num2;
                case '*':
                    return num1 * num2;
                case '/':
                    if(num2 == 0)
                        return 0;
                    else
                        return num1 / num2;
                default:
                    return -1;
            }
        }
    }
}
